//
//  main.swift
//  MusicianClass
//
//  Created by Atil Samancioglu on 10.07.2019.
//  Copyright © 2019 Atil Samancioglu. All rights reserved.
//

import Foundation

let james = Musicians(nameInit: "James", ageInit: 50, instrumentInit: "Guitar", typeInit: .Vocalist)
james.sing()

let kirk = SuperMusician(nameInit: "Kirk", ageInit: 55, instrumentInit: "Guitar", typeInit: .LeadGuitar)
//kirk.sing()
//kirk.sing2()



