//
//  WidgetHeroApp.swift
//  WidgetHero
//
//  Created by Atil Samancioglu on 10.08.2020.
//

import SwiftUI

@main
struct WidgetHeroApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
